(function () {
	angular.module("HotelApp", [
		"ngResource",
		"ngRoute",
		"ngCookies",
		"common-directives",
		"common-factories",
		"angular-growl",
		"common-filters",
		"common-controllers",
		"common-services",
	]);
})();
